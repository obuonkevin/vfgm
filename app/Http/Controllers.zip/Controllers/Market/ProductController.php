<?php

namespace App\Http\Controllers\Market;

use App\Http\Controllers\Controller;
use App\Http\Requests\Market\ProductRequest;

use App\Model\Market\Product;


use App\Model\Market\Vendor;
use App\User;
use Illuminate\Http\Request;

class ProductController extends Controller
{

    public function index()
    {
        $results = Product::with(['user', 'vendor', 'category'])->get();
        return view('admin.market.product.index', ['results' => $results]);
    }


    public function create()
    {
        return view('admin.market.product.form');
    }


    public function store(ProductRequest $request)
    {
        $input = $request->all();
        try {
            Product::create($input);
            $bug = 0;
        } catch (\Exception $e) {
            $bug = $e->errorInfo[1];
        }

        if ($bug == 0) {
            return redirect('product')->with('success', 'Product successfully saved.');
        } else {
            return redirect('product')->with('error', 'Something Error Found !, Please try again.');
        }
    }


    public function edit($id)
    {
        $editModeData = Product::findOrFail($id);
        return view('admin.market.product.form', ['editModeData' => $editModeData]);
    }


    public function update(ProductRequest $request, $id)
    {
        $product = Product::findOrFail($id);
        $input = $request->all();
        try {
            $product->update($input);
            $bug = 0;
        } catch (\Exception $e) {
            $bug = $e->errorInfo[1];
        }

        if ($bug == 0) {
            return redirect()->back()->with('success', 'Product successfully updated ');
        } else {
            return redirect()->back()->with('error', 'Something Error Found !, Please try again.');
        }
    }


    public function destroy($id)
    {

        try {
            $product = Product::FindOrFail($id);
            $product->delete();
            $bug = 0;
        } catch (\Exception $e) {
            $bug = $e->errorInfo[1];
        }

        if ($bug == 0) {
            echo "success";
        } elseif ($bug == 1451) {
            echo 'hasForeignKey';
        } else {
            echo 'error';
        }
    }

    public function APICreateProduct(Request $request)
    {
        $block_one = function ($params) {

            $input = $params['request']->all();

            $input['user_id'] = $params['user']->user_id;

            $vendor = Vendor::where('user_id',  $params['user']->user_id)->first();

            $input['vendor_id'] = $vendor->vendor_id;

            if (Product::create($input)) {
                $status = true;
                $message = "Product created successfully!";
            } else {
                $status = false;
                $message = "Your action failed. Please try again";
            }

            return ['success' => $status, 'data' => [], 'message' => $message];
        };

        $response = executeRestrictedAccess($block_one, "auth", ['request' => $request], false);

        return response()->json($response);
    }

    public function APIVendorProducts(Request $request)
    {
        $block_one = function ($params) {

            $products = Product::with(['user', 'vendor' =>function($q){
                $q->with(['county', 'location']);
            }])->where('user_id', $params['user']->user_id)->get();
            $status = false;
            $message = "";

            $data = [];
            if (!$products->isEmpty()) {
                foreach ($products as $key => $product) {
                    $object = (object) [
                        'id' => $product->product_id,
                        'vendor_id' => $product->vendor_id,
                        'category_id' => $product->category_id,
                        'name' => $product->name,
                        'price' => $product->price,
                        'delivery_cost' => $product->delivery_cost,
                        'description' => $product->description,
                        'created_at' => $product->created_at->toDateString(),
                        'updated_at' => $product->updated_at->toDateString(),
                        'vendor_name' => isset($product->vendor) ? $product->vendor->name : '',
                        'vendor_email' => isset($product->user) ? $product->user->email : '',
                        'vendor_phone_no' => isset($product->user) ? $product->user->phone_no : '',
                        'vendor_county' => isset($product->vendor->county) ? $product->vendor->county->county_name : '',
                        'vendor_location' => isset($product->vendor->location) ? $product->vendor->location->location_name : '',
                        'images' => [],
                    ];
                    array_push($data, $object);
                }

                $status = true;
                $message = "";
            } else {
                $status = false;
                $message = "You have not added any product yet!";
            }

            return ['success' => $status, 'data' => $data, 'message' => $message];
        };

        $response = executeRestrictedAccess($block_one, "auth", ['request' => $request], false);
        return response()->json($response);
    }


    public function APIProducts(Request $request)
    {
        $block_one = function ($params) {

            $products = Product::with(['user', 'vendor' =>function($q){
                $q->with(['county', 'location']);
            }])->orderBy('created_at', 'desc')->get();
            $status = false;
            $message = "";

            $data = [];
            if (!$products->isEmpty()) {
                foreach ($products as $key => $product) {
                    $object = (object) [
                        'id' => $product->product_id,
                        'vendor_id' => $product->vendor_id,
                        'category_id' => $product->category_id,
                        'name' => $product->name,
                        'price' => $product->price,
                        'delivery_cost' => $product->delivery_cost,
                        'description' => $product->description,
                        'created_at' => $product->created_at->toDateString(),
                        'updated_at' => $product->updated_at->toDateString(),
                        'vendor_name' => isset($product->vendor) ? $product->vendor->name : '',
                        'vendor_email' => isset($product->user) ? $product->user->email : '',
                        'vendor_phone_no' => isset($product->user) ? $product->user->phone_no : '',
                        'vendor_county' => isset($product->vendor->county) ? $product->vendor->county->county_name : '',
                        'vendor_location' => isset($product->vendor->location) ? $product->vendor->location->location_name : '',
                        'images' => [],
                    ];
                    array_push($data, $object);
                }

                $status = true;
                $message = "";
            } else {
                $status = false;
                $message = "You have not added any product yet!";
            }

            return ['success' => $status, 'data' => $data, 'message' => $message];
        };

        $response = executeRestrictedAccess($block_one, "auth", ['request' => $request], false);
        return response()->json($response);
    }
}
